/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realtec;
import ModeloConnection.Banco;
import Visualização.Home_Page;


public class Realtec {

    public static void main(String[] args) {
        Home_Page tela = new Home_Page();
        tela.setVisible(true);
        
    }
    
}
